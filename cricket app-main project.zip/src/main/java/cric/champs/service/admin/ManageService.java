package cric.champs.service.admin;

public class ManageService {
}
