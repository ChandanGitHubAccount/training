package cric.champs.service;

public enum StrikePosition {
    STRIKE,NONSTRIKE
}
