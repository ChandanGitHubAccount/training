package cric.champs.service;

public enum WicketType {
    HITWICKET, STUMPED, CAUGHT, RUNOUT, LBW, BOWLED, OTHERS
}
