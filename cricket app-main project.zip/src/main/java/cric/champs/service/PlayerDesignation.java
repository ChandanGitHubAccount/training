package cric.champs.service;

public enum PlayerDesignation {
    Captain,ViceCaptain
}
