package cric.champs.service;

public enum TeamStatus {
    WIN, LOSS
}
