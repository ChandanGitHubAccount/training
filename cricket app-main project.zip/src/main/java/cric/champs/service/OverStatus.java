package cric.champs.service;

public enum OverStatus {
    DONE,COMPLETED,NOTCOMPLETED
}
