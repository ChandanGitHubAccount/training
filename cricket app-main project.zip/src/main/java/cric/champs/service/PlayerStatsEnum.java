package cric.champs.service;

public enum PlayerStatsEnum {
    bestBowlingStrikeRate, bestBowlingEconomy, mostFiveWicketsHaul, bestBowlingAverage, mostWickets, totalSixes, totalFours,
    totalFifties, totalHundreds, battingStrikeRate, battingAverage, mostRuns

}
