package cric.champs.service;

public enum TournamentTypes {
    LEAGUE, KNOCKOUT, INDIVIDUALMATCH
}
