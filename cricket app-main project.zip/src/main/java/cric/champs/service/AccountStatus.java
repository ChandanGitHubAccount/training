package cric.champs.service;

public enum AccountStatus {
    VERIFIED, NOTVERIFIED
}
