package cric.champs.customexceptions;

public class OTPGenerateException extends Exception{
    public OTPGenerateException(String message) {
        super(message);
    }
}
