package cric.champs.customexceptions;

public class UsernameNotFoundExceptions extends Exception{
    public UsernameNotFoundExceptions(String message) {
        super(message);
    }
}
