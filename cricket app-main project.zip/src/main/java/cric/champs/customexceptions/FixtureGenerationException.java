package cric.champs.customexceptions;

public class FixtureGenerationException extends Exception{
    public FixtureGenerationException(String message) {
        super(message);
    }
}
