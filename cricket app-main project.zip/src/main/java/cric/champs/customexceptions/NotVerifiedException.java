package cric.champs.customexceptions;

public class NotVerifiedException extends Exception{
    public NotVerifiedException(String message) {
        super(message);
    }
}
