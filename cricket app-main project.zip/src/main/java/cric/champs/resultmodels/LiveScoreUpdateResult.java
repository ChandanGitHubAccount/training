package cric.champs.resultmodels;

public class LiveScoreUpdateResult {

    private Long tournamentId;

    private Long matchId;

    private Long battingTeamId;

    private Long strikePlayerId;

    private Long nonStrikePlayerId;

    private String overStatus;

    private String matchStatus;

}
