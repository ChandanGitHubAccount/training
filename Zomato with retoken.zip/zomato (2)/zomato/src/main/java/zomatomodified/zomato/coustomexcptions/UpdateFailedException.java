package zomatomodified.zomato.coustomexcptions;

public class UpdateFailedException extends Exception{
    public UpdateFailedException(String message) {
        super(message);
    }
}
