package zomatomodified.zomato.service;

public enum OrderStatus {
    CONFIRMED, CANCELLED, PAYMENTPENDING
}
